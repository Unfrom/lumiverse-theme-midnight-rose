# Midnight Rose Theme for Lumiverse (Kawaii Dark / Pastel Goth)

Based on the Discord theme conversation between Goldie & Un.

## Quick Setup (Choose Option A, B, or C)

### Option A: Import Theme Settings (Simplest)
1. In Lumiverse, open the **Theme Panel**.
2. Click **Import** and select `theme.json`.
3. Sets Dark Mode, Baby Rose accent (`#f285ad`), plum base backgrounds (`#140d18`), and High Radius scale.

### Option B: Paste Custom CSS (Recommended for full look)
1. Go to **Settings → Appearance → Custom CSS** (or open the Custom CSS modal from the Theme Panel).
2. Copy and paste the contents of `custom.css` into the editor.
3. Save. This immediately activates:
   - Floating heart watermark pattern
   - Rounded chat speech bubbles (18px) with dusty mauve borders (`#a05978`)
   - Deep aubergine message backgrounds & pink focus rings
   - `NEW ♥` unread separator badge
   - Pill-shaped composer input bar
   - Quicksand/Comfortaa rounded typography
   - Custom minimalist rose scrollbars

### Option C: Import Theme Pack (.zip)
1. In the **Custom CSS** modal, click **Import Pack**.
2. Select `midnight-rose-theme-pack.zip`.

---

## Palette Reference

| Element | Color | Hex |
| :--- | :--- | :--- |
| **Canvas Background** | Midnight Aubergine / Deep Plum | `#140d18` |
| **Card / Incoming Bubble** | Dusty Raisin | `#281b2a` |
| **Outgoing User Bubble** | Muted Royal Plum | `#351f38` |
| **Bubble Outlines** | Soft Dusty Mauve | `#a05978` |
| **Primary Accent & Highlights** | Baby Rose / Pastel Pink | `#f285ad` |
| **Typography** | Lilac Cream White | `#f0e8f2` |
| **Muted Text / Timestamps** | Lavender Slate | `#8a768e` |
